﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signup
{
    internal class info
    {
        public int ID { set; get; }
        public string? fName { set; get; }
        public string? LName { set; get; }
        public string? Sex { set; get; }
        public string? Bdate { set; get; }
        public string? Email { set; get; }
        public string? Occup { set; get; }
        public int User_ID { set; get; }
        public int Signup_ID { set; get; }
        public string? Username { set; get; }
        public string? Password { set; get; }
        public string? Signup_Username { set; get; }
        public string? Signup_Password { set; get; }
        public string? Signup_confirm_password { set; get; }
        

    }
}
